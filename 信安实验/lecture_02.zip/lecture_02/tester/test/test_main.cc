#define CATCH_CONFIG_MAIN
#include "catch2/catch.hpp"

// DO not write any test cases in here
//   Why? To save compiling time for you
