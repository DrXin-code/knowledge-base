#include "../implementation/unit_2.cc"
#include "catch2/catch.hpp"

using namespace std;

TEST_CASE("Modular exponentiation", "[unit_2]")
{

    SECTION("Modular exponentiation: Small data entry")
    {
        REQUIRE(mod_exp(1, 1, 1) == 0);
        REQUIRE(mod_exp(1, 100, 1) == 0);
        REQUIRE(mod_exp(0, 1, 1) == 0);
        REQUIRE(mod_exp(0, 100, 1) == 0);
        REQUIRE(mod_exp(1, 1, 2) == 1);
        REQUIRE(mod_exp(1, 100, 2) == 1);
        REQUIRE(mod_exp(0, 1, 2) == 0);
        REQUIRE(mod_exp(0, 100, 2) == 0);
    }

    SECTION("Modular exponentiation: Big data entry")
    {
        REQUIRE(mod_exp(6, 128, 5) == 1);
        REQUIRE(mod_exp(6, 65535, 7) == 6);
        REQUIRE(mod_exp(6, 4294967295, 9) == 0);
        REQUIRE(mod_exp(128, 4294967295, 11) == 10);
        REQUIRE(mod_exp(4096, 4294967295, 13) == 1);
        REQUIRE(mod_exp(4294967295, 4294967295, 19) == 11);
    }
}

TEST_CASE("Prime Test: Eratosthenes screening method", "[unit_2]")
{

    SECTION("Prime Test: Small data entry")
    {
        REQUIRE(prime_test(2) == true);
        REQUIRE(prime_test(59) == true);
        REQUIRE(prime_test(647) == true);
        REQUIRE(prime_test(937) == true);
        REQUIRE(prime_test(6367) == true);
        REQUIRE(prime_test(7823) == true);
        REQUIRE(prime_test(56123) == true);
        REQUIRE(prime_test(54121) == true);
        REQUIRE(prime_test(76080) == false);
        REQUIRE(prime_test(77253) == false);
    }

    SECTION("Prime Test: Big data entry")
    {
        REQUIRE(prime_test(153073) == true);
        REQUIRE(prime_test(339659) == true);
        REQUIRE(prime_test(976187) == true);
        REQUIRE(prime_test(4294967291) == true);
        REQUIRE(prime_test(153074) == false);
        REQUIRE(prime_test(530763) == false);
        REQUIRE(prime_test(720255) == false);
        REQUIRE(prime_test(4294967295) == false);
        REQUIRE(prime_test(4294967294) == false);
    }

    SECTION("Prime Test: special cases")
    {
        REQUIRE(prime_test(1) == false);
        REQUIRE(prime_test(0) == false);
    }
}
