#include <cmath>
#include <iostream>

unsigned int mod_exp(unsigned int a, unsigned int e, unsigned int m)
{
    // TODO: return the answer of a^e mod m";
}

bool prime_test(unsigned int a)
{
    //TODO: return true when "a" is a prime | False when "a" is not a prime";
}